import express from "express";
import bodyParser from "body-parser";
import fetch from "node-fetch";
import dotenv from "dotenv";

dotenv.config();
const app = express();
app.use(bodyParser.json());

// ✅ API route for auto-assign
app.post("/auto-assign", async (req, res) => {
  try {
    const { bookingData, employees } = req.body;

    const prompt = `
    You are a scheduling assistant.
    Booking details: ${JSON.stringify(bookingData)}
    Available employees: ${JSON.stringify(employees)}
    Assign ${bookingData.cleaners} cleaners fairly.
    Prefer employees with lower "hoursWorked" to balance workloads.
    Respond ONLY in JSON like: {"assignedCleaners":["Name1","Name2"]}.
    `;

	const response = await fetch("http://localhost:3000/auto-assign", {
	  method: "POST",
	  headers: { "Content-Type": "application/json" },
	  body: JSON.stringify({ bookingData, employees: activeEmployees })
	});

	const parsed = await response.json();

    const result = await response.json();
    const content = result.choices[0].message.content;
    res.json(JSON.parse(content));
  } catch (err) {
    console.error("❌ Auto-assign failed:", err);
    res.status(500).json({ error: "Failed to auto-assign cleaners" });
  }
});

// ✅ Start server
app.listen(3000, () => console.log("Server running on http://localhost:3000"));
