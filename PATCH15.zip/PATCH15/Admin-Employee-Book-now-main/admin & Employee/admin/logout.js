function logout() {
  // Redirect to homepage
  window.location.href = "index.html"; // Change to your homepage file
}
