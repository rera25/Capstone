// aiScheduler.js
// Auto-sorting + AI scheduling assistant for Firebase bookings

// ---- Sorting Utility ----
function sortBookings(bookings) {
  const timeOrder = { morning: 1, afternoon: 2, evening: 3, night: 4 };
  return bookings.sort((a, b) => {
    if (a.booking.detailsDate === b.booking.detailsDate) {
      return (timeOrder[a.booking.time] || 99) - (timeOrder[b.booking.time] || 99);
    }
    return new Date(a.booking.detailsDate) - new Date(b.booking.detailsDate);
  });
}

// ---- AI Assistant ----
const url = 'https://chatgpt-42.p.rapidapi.com/aitohuman';

const options = {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-rapidapi-key": "f5fc088792msh38dabfb1feac9a5p13060fjsnbcebec85d81d", // 🔑 Replace with your key
      "x-rapidapi-host": "chatgpt-42.p.rapidapi.com"
    },
		body: JSON.stringify({
		  text: `Here are the bookings: ${globalBookings.map(b => 
			`${b.booking.detailsDate} at ${b.booking.time}`
		  ).join(", ")}. 

		User request: ${userMessage}`
		})
  };

try {
  const response = fetch(url, options);
  const result = response.text(); // or response.json() if API always returns JSON
  console.log(result);
} catch (error) {
  console.error(error);
}




// ---- Export to global scope so dashboard.html can use it ----
window.aiScheduler = {
  sortBookings,
  askAI
};
