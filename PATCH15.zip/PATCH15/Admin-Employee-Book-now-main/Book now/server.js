const express = require("express");
const bodyParser = require("body-parser");
const admin = require("firebase-admin");
const OpenAI = require("openai");
require("dotenv").config();

dotenv.config();

const app = express();
app.use(bodyParser.json());

// 🔹 Init Firebase
const serviceAccount = JSON.parse(fs.readFileSync("./serviceAccountKey.json", "utf8"));
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://test-81103-default-rtdb.firebaseio.com"
});

const db = admin.database();

// 🔹 Init OpenAI
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// 🔹 Route: Sort schedules with AI
app.get("/sort-schedules", async (req, res) => {
  try {
    const snapshot = await db.ref("schedule").once("value");
    const schedules = snapshot.val();

    if (!schedules) {
      return res.status(404).json({ message: "No schedules found." });
    }

    // Ask OpenAI to sort
    const completion = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are an assistant that sorts schedules by date and time in chronological order. Respond with JSON only."
        },
        {
          role: "user",
          content: JSON.stringify(schedules)
        }
      ],
      temperature: 0,
    });

    const sortedSchedules = JSON.parse(completion.choices[0].message.content);
    res.json(sortedSchedules);

  } catch (error) {
    console.error("❌ Error sorting schedules:", error);
    res.status(500).json({ error: error.message });
  }
});

// 🔹 Start server
const PORT = 3000;
app.listen(PORT, () => console.log(`🚀 Server running on http://localhost:${PORT}`));
