const menuIcon = document.getElementById("menu-icon");
  const navRight = document.querySelector(".nav-right");

  menuIcon.onclick = () => {
    navRight.classList.toggle("active");
    menuIcon.classList.toggle("bx-x"); // changes icon to X when active
  };
  

  const notificationIcon = document.getElementById("notificationIcon");
const notificationDropdown = document.getElementById("notificationDropdown");

notificationIcon.addEventListener("click", () => {
  notificationDropdown.style.display = 
    notificationDropdown.style.display === "block" ? "none" : "block";
});


document.addEventListener("click", (event) => {
  if (!notificationIcon.contains(event.target) && 
      !notificationDropdown.contains(event.target)) {
    notificationDropdown.style.display = "none";
  }
});


window.addEventListener("scroll", function() {
    const header = document.querySelector("header");
    if (window.scrollY > 50) {
        header.classList.add("scrolled");
    } else {
        header.classList.remove("scrolled");
    }
});

function showSidebar(){
  document.querySelector('.sidebar').style.display = 'flex';
}
function hideSidebar(){
  document.querySelector('.sidebar').style.display = 'none';
}

document.querySelectorAll('.faq-question').forEach(q => {
  q.addEventListener('click', () => {
    const answer = q.nextElementSibling;
    answer.style.display = answer.style.display === 'block' ? 'none' : 'block';
  });
});



const fadeElements = document.querySelectorAll('.fade-up');

function revealOnScroll() {
  fadeElements.forEach(el => {
    const elementTop = el.getBoundingClientRect().top;
    const windowHeight = window.innerHeight;
    if (elementTop < windowHeight - 50) {
      el.classList.add('show');
    }
  });
}

window.addEventListener('scroll', revealOnScroll);
revealOnScroll();


 var swiper = new Swiper(".testimonial-swiper", {
    slidesPerView: 3,
    spaceBetween: 20,
    loop: true,
    autoplay: {
      delay: 3000,
      disableOnInteraction: true,
    },
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },
    breakpoints: {
      768: { slidesPerView: 3 },
      480: { slidesPerView: 2 },
      0: { slidesPerView: 1 }
    }
  });

  const animatedElements = document.querySelectorAll('.fade-up, .fade-left, .fade-right');

  function checkAnimation() {
    let triggerBottom = window.innerHeight * 0.85;

    animatedElements.forEach(el => {
      const elementTop = el.getBoundingClientRect().top;
      if (elementTop < triggerBottom) {
        el.classList.add('show');
      }
    });
  }

  window.addEventListener('scroll', checkAnimation);
  window.addEventListener('load', checkAnimation);

  const animatedEls = document.querySelectorAll('.fade-left, .fade-right');

  function triggerAnimations() {
    let triggerPoint = window.innerHeight * 0.85;
    animatedEls.forEach(el => {
      const elementTop = el.getBoundingClientRect().top;
      if (elementTop < triggerPoint) {
        el.classList.add('show');
      }
    });
  }

  window.addEventListener('scroll', triggerAnimations);
  window.addEventListener('load', triggerAnimations);

  var locationSwiper = new Swiper(".location-swiper", {
  slidesPerView: 3,
  spaceBetween: 20,
  loop: true,
  autoplay: {
    delay: 3000,
    disableOnInteraction: false,
  },
  navigation: {
    nextEl: ".location-swiper .swiper-button-next",
    prevEl: ".location-swiper .swiper-button-prev",
  },
  breakpoints: {
    992: { slidesPerView: 3 },
    768: { slidesPerView: 2 },  
    0: { slidesPerView: 1 }
  }
});



