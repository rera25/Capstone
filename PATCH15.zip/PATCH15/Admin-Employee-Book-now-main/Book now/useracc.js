function useracc() {
  // Redirect to homepage
  window.location.href = "useracc.html"; // Change to your homepage file
}