function faq() {
  // Redirect to homepage
  window.location.href = "faq.html"; // Change to your homepage file
}