function aboutus() {
  // Redirect to homepage
  window.location.href = "aboutus.html"; // Change to your homepage file
}